#ifndef IMAGEPANE_H
#define IMAGEPANE_H
#include "mainwindow.h"
#include "ui_mainwindow.h"
#endif // IMAGEPANE_H
#include <QFileDialog>
#include <QMessageBox>
#include <QDir>
#include <ui_mainwindow.h>

class ImagePane{

   Q_OBJECT
    private:

    public:







};
