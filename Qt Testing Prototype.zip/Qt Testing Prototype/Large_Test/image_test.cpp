#include "image.h"


void Image::testing_image_name(int test_image_name)
{
     image_name = test_image_name;
}

