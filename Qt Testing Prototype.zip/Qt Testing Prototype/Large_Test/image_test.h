#ifndef IMAGE_TEST_H
#define IMAGE_TEST_H

#include <image.h>

class image_test : public Image
{
    Q_OBJECT
public:
    image_test();

    void testing_image_name( int test_image_name );

};

#endif // IMAGE_TEST_H
