#include <QtTest/QtTest>
#include <QCoreApplication>
#include <image.h>
#include <image_test.h>
// add necessary includes here

class Unit_Test : public QObject
{
    Q_OBJECT

private slots:
    void initTestCase();
    void cleanupTestCase();

    void get_image_path_default();
    void get_image_name_default();
    void get_image_name_exists();
    //void load_image_into_canvas_test();
    //void set_image_name_test();
    //void set_image_path_test();

};

void Unit_Test::initTestCase()
{

}

void Unit_Test::cleanupTestCase()
{

}



void Unit_Test::get_image_name_default()
{

    // Setup the test
    Image model;

    // Test
    QVERIFY2( model.get_image_name() == 0, "Expect input to be zero by default");
}

void Unit_Test::get_image_name_exists()
{
    Image model;
    QVERIFY2( model.get_image_name() == 0,"Expect 0");

    int expect( 100 );
    model.testing_image_name(expect);

    QString actual = model.get_image_name();

    QVERIFY2( actual == expect,
              QString("Expect [%1] but actually got [%2] instead.").arg(expect).arg(actual).toStdString().c_str());

}

void Unit_Test::get_image_path_default()
{
    Image model;

    QVERIFY2( model.get_image_path() == 0,"Expect 0");
}

QTEST_MAIN(Unit_Test)

#include "tst_unit_test.moc"
