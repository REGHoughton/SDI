#include <QtTest>

// add necessary includes here

class Unit_Test : public QObject
{
    Q_OBJECT

public:
    Unit_Test();
    ~Unit_Test();

private slots:
    void initTestCase();
    void cleanupTestCase();
    void test_case1();

};

Unit_Test::Unit_Test()
{

}

Unit_Test::~Unit_Test()
{

}

void Unit_Test::initTestCase()
{

}

void Unit_Test::cleanupTestCase()
{

}

void Unit_Test::test_case1()
{

}

QTEST_APPLESS_MAIN(Unit_Test)

#include "tst_unit_test.moc"
