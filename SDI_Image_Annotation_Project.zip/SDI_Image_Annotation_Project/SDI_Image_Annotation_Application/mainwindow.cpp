#include <QFileDialog>
#include <QMessageBox>
#include <QDir>
#include <QFile>
#include <QTextStream>
#include <QDirIterator>
#include <qdebug.h>
#include <QVector2D>
#include "image.h"
#include "mainwindow.h"
#include "ui_mainwindow_copy.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

}

MainWindow::~MainWindow()
{

    delete ui;

}

//SELECTING IMAGE DIRECTORY
void MainWindow::on_btn_Select_Image_Folder_clicked()
{

    QStringList arr_image_names;
    QString filter2 = "Class File (*.names)";
    QString folder_name = QFileDialog::getExistingDirectory(this, ("Select Output Folder"),"C:/Users/mateu/Desktop");
    QDir dir_2(folder_name);

    //Look at each file within directory
    foreach(QFileInfo var, dir_2.entryInfoList()){
        //If file suffix == jpg
        if (var.suffix() == "jpg"){
            //Store image data in Vectors
            image_data.append(var.filePath());
            image_data.append(var.baseName());
            //Pass image name into UI to be displayed
            ui->image_List->addItem(var.baseName());
            //Add to list with image names used for sorting.
            images_list << var.baseName();
            //New instance of image class           NEEDS TO BE MADE SO IT IS STORED IN AN ARRAY, THEN MOST OF ABOVE STORAGE IS NOT NEEDED!!!!
            Image newImage;

        }
   }
    //qDebug()<< image_Names;

    //Change gui label showing path of current directory.
    ui->folder_Path_Image->setText(folder_name);
}

//SELECTING AN IMAGE TO LOAD INTO CANVAS
void MainWindow::on_image_List_currentTextChanged(const QString &currentText)
{
    qDebug()<< "ImageList" << currentText;

    //Find the image path by looking at Vector with image name and full path.
    int file_path_index = image_data.indexOf(currentText)-1;
    QString filename = image_data[file_path_index];
    //Send corresponding image to canvas.
    QImage image(filename);
    ui->canvas->setPixmap(QPixmap::fromImage(image));
}

//SELECTING FILE FOR CLASS FILES
void MainWindow::on_btn_Select_Class_File_clicked()
{

    //Track line number within file
    int line_number=0;

    QString filter = "Class File (*.names)";
    QString file_name = QFileDialog::getOpenFileName(this,"Open class file","C:/Users/mateu/Desktop",filter);
    QFile file(file_name);


    if (!file.open(QFile::ReadOnly | QFile::Text)){
        QMessageBox::warning(this,"title","file not open");
    }

    QTextStream in(&file);
    while(!in.atEnd()){
        line_number ++;
        //Each line = different class/
        QString class_name = in.readLine();
        //New instance of AnnotationClass class,  NEEDS TO BE MADE SO IT IS STORED IN AN ARRAY, THEN MOST OF ABOVE STORAGE IS NOT NEEDED!!!!
        AnnotationClass object_name;

        //Set current objects name and line number.
        object_name.set_name_and_line(class_name,line_number);

        //Display items in class_List.
        ui->class_List->addItem(class_name);

    }

    file.close();
    ui->folder_Path_Class->setText(file.fileName());


}


