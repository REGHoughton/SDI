/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[17];
    char stringdata0[358];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 32), // "on_btn_Select_Class_File_clicked"
QT_MOC_LITERAL(2, 44, 0), // ""
QT_MOC_LITERAL(3, 45, 34), // "on_btn_Select_Image_Folder_cl..."
QT_MOC_LITERAL(4, 80, 32), // "on_image_List_currentTextChanged"
QT_MOC_LITERAL(5, 113, 11), // "currentText"
QT_MOC_LITERAL(6, 125, 32), // "on_dropdown_Sort_Image_activated"
QT_MOC_LITERAL(7, 158, 5), // "index"
QT_MOC_LITERAL(8, 164, 32), // "on_dropdown_Sort_Class_activated"
QT_MOC_LITERAL(9, 197, 17), // "on_canvas_pressed"
QT_MOC_LITERAL(10, 215, 14), // "sorting_images"
QT_MOC_LITERAL(11, 230, 9), // "item_list"
QT_MOC_LITERAL(12, 240, 23), // "ascending_or_descending"
QT_MOC_LITERAL(13, 264, 28), // "on_rad_Btn_Rectangle_toggled"
QT_MOC_LITERAL(14, 293, 7), // "checked"
QT_MOC_LITERAL(15, 301, 28), // "on_rad_Btn_Trapezium_toggled"
QT_MOC_LITERAL(16, 330, 27) // "on_rad_Btn_Triangle_toggled"

    },
    "MainWindow\0on_btn_Select_Class_File_clicked\0"
    "\0on_btn_Select_Image_Folder_clicked\0"
    "on_image_List_currentTextChanged\0"
    "currentText\0on_dropdown_Sort_Image_activated\0"
    "index\0on_dropdown_Sort_Class_activated\0"
    "on_canvas_pressed\0sorting_images\0"
    "item_list\0ascending_or_descending\0"
    "on_rad_Btn_Rectangle_toggled\0checked\0"
    "on_rad_Btn_Trapezium_toggled\0"
    "on_rad_Btn_Triangle_toggled"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   64,    2, 0x08 /* Private */,
       3,    0,   65,    2, 0x08 /* Private */,
       4,    1,   66,    2, 0x08 /* Private */,
       6,    1,   69,    2, 0x08 /* Private */,
       8,    1,   72,    2, 0x08 /* Private */,
       9,    0,   75,    2, 0x08 /* Private */,
      10,    2,   76,    2, 0x08 /* Private */,
      13,    1,   81,    2, 0x08 /* Private */,
      15,    1,   84,    2, 0x08 /* Private */,
      16,    1,   87,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void,
    QMetaType::QStringList, QMetaType::QStringList, QMetaType::QString,   11,   12,
    QMetaType::Void, QMetaType::Bool,   14,
    QMetaType::Void, QMetaType::Bool,   14,
    QMetaType::Void, QMetaType::Bool,   14,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_btn_Select_Class_File_clicked(); break;
        case 1: _t->on_btn_Select_Image_Folder_clicked(); break;
        case 2: _t->on_image_List_currentTextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->on_dropdown_Sort_Image_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->on_dropdown_Sort_Class_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->on_canvas_pressed(); break;
        case 6: { QStringList _r = _t->sorting_images((*reinterpret_cast< QStringList(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< QStringList*>(_a[0]) = std::move(_r); }  break;
        case 7: _t->on_rad_Btn_Rectangle_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 8: _t->on_rad_Btn_Trapezium_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 9: _t->on_rad_Btn_Triangle_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 10;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
